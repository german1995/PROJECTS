package pack1;

public class Product {
   public String p_name;
    public int qty,price;

    public Product(String p_name, int qty, int price) {
        this.p_name = p_name;
        this.qty = qty;
        this.price = price;
    }
    
    
}
