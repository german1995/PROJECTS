
import ch.randelshofer.media.avi.AVIOutputStream;
import java.io.File;
import java.io.FileInputStream;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class video 
{
    video()
    {
         File f = new File("d:\\vivek\\test.avi");
    
         try{
             AVIOutputStream av = new AVIOutputStream(f, AVIOutputStream.VideoFormat.JPG);

         
        


       
            
          
            File f2 = new File("C:\\Users\\admin\\screenshot\\bradpit\\2015-07-14"); 
        
           
            
           
            int len = f2.listFiles().length;
             
             av.setFrameRate(3);
            av.setVideoDimension(500, 500);
            
           
            for (int  i =1 ; i <= len; i++) 
            {
                File f1 = new File(f2+"\\"+i + ".jpg");
                FileInputStream fis = new FileInputStream(f1);
                av.writeFrame(fis);
                System.out.println("Image fetched : " + i);
            }
              
	av.close();
}
         catch(Exception e)
         {
             e.printStackTrace();
         }
    }
    
    public static void main(String[] args) {
            video ob=new video();

    }
    
}
