import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class login_servlet extends HttpServlet {

  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String names[]={"abc","def","xyz","mno"};
        int passwords[] = {123,234,456,678};
        
        String uname = request.getParameter("username");
        int pass =    Integer.parseInt(request.getParameter("password"));
        
        int flag=0;
        for (int i = 0; i < 4; i++) {
            if(names[i].equals(uname) && passwords[i]==pass)
            {
                flag=1;
            }             
        }
        
        if(flag==0)
        {
            response.sendRedirect("login1.html");
        }
        else
        {
            response.sendRedirect("./success");
        }
        
                        
        
    }

}
