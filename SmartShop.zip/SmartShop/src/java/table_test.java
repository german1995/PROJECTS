
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class table_test extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        response.setContentType("text/html");
        PrintWriter out =response.getWriter();
        
        int rn[] ={1,2,3,4,5};
        String names[] ={"abc","def","xyz","mno","test"};
        
        out.println("<html>");
        
        out.println("<body>");
        out.println("<h1>List of Students</h1>");
        out.println("<table border=\"2\">");
        
        out.println("<tr>");
        out.println("<th>Roll NO</th>");
        out.println("<th>Name</th>");
        out.println("</tr>");
        
        for (int i = 0; i < 5; i++) {
            out.println("<tr>");
            out.println("<td>"+rn[i]+"</td>");
            out.println("<td>"+names[i]+"</td>");
            out.println("</tr>");                       
        }
        
        
        out.println("</table>");
        out.println("</body>");
        
        
        out.println("</html>");
        
        
        
        
        
        
    }
}
