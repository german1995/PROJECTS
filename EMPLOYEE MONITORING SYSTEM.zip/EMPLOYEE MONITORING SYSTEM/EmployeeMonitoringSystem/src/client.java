
import java.io.*;
import java.net.Socket;


public class client implements Runnable
{
    DataInputStream dis;
    DataOutputStream dos;
    Socket sock;
    
    @Override
  public void run()
    {
        try
        
        {
              sock=new Socket("127.0.0.1",7172);
            
              while(true)
              {
              dos=new DataOutputStream(sock.getOutputStream());
              dis=new DataInputStream(sock.getInputStream());
              dos.writeBytes("hello server\r\n");
               System.out.println(dis.readLine());
              }
              
           
               
             

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
}

    
}