
import java.io.*;
import java.net.*;


public class server implements Runnable
{
    
    
    ServerSocket sersock;
    Socket sock;
    
    @Override
  public void run()
    {
        
       try
       {
          sersock=new ServerSocket(7172);
          while(true)
          {
              sock=sersock.accept();
              Thread t=new Thread(new clientHandler(sock));
              t.start();
          }
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
    }
   
    
    ////inner class////
    class clientHandler implements Runnable
    {   Socket sock;
        DataInputStream dis;
        DataOutputStream dos;
        
        clientHandler(Socket sock)
        {
            this.sock=sock;
        }

        
        @Override
        public void run() 
        {
        
        try
        {
            while(true)
            {
         dos=new DataOutputStream(sock.getOutputStream());
        dis=new DataInputStream(sock.getInputStream());
        
        dos.writeBytes("hello client\r\n");
        
        System.out.println(dis.readLine());
            }
       
        }
        
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        }
    }
}