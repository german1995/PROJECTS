
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
class photoclient implements Runnable
{
    

    DataInputStream pdis;
    DataOutputStream pdos;
    Socket psock;
    
    @Override
  public void run()
    {
        try
        
        {
              psock=new Socket("127.0.0.1",7271);
            
              while(true)
              {
              pdos=new DataOutputStream(psock.getOutputStream());
              pdis=new DataInputStream(psock.getInputStream());
              pdos.writeBytes("hello  photo server\r\n");
               System.out.println(pdis.readLine());
              }
              
           
               
             

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
}
    
    }

    


