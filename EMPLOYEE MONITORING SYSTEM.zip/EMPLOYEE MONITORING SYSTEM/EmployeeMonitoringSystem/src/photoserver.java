
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class photoserver implements Runnable
{
    
    
    ServerSocket psersock;
    Socket psock;
    
    @Override
  public void run()
    {
        
       try
       {
          psersock=new ServerSocket(7271);
          while(true)
          {
              psock=psersock.accept();
              Thread t=new Thread(new pclientHandler(psock));
              t.start();
          }
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
    }
   
    
    ////inner class////
    class pclientHandler implements Runnable
    {   Socket psock;
        DataInputStream pdis;
        DataOutputStream pdos;
        
        pclientHandler(Socket sock)
        {
            this.psock=psock;
        }

        
        @Override
        public void run() 
        {
        
        try
        {
            while(true)
            {
         pdos=new DataOutputStream(psock.getOutputStream());
        pdis=new DataInputStream(psock.getInputStream());
        
        pdos.writeBytes("hello photo client\r\n");
        
        System.out.println(pdis.readLine());
            }
       
        }
        
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        }
    }
}
    

