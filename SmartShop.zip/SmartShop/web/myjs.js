
function go()
{
    alert('hello world');
}