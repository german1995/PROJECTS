
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Filter extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                
            String query = request.getParameter("q");
            String option = request.getParameter("r1");
            
            if(option.equalsIgnoreCase("google"))
            { 
                response.sendRedirect("http://www.google.com/search?q="+query);
            }
            else if(option.equalsIgnoreCase("yahoo"))
            {
                 response.sendRedirect("http://search.yahoo.com/search?p="+query);

            }
            else
            {
                  response.sendRedirect("http://www.bing.com/search?q="+query);
              
            }
            
            
        
        }
    

}
